package com.jarvis.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var cancelBtn: Button

    private val handler = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null
    private var idleTask: Runnable? = null
    private val actionLog = ArrayList<String>()

    private val cyan = 0xFF00E5FF.toInt()
    private val bg = 0xFF05080F.toInt()

    private val helpText =
        "Right now I can:\n" +
        "- tell you the time and date (\"what time is it\")\n" +
        "- report battery level and charging (\"battery\")\n" +
        "- open system settings (\"open settings\")\n" +
        "- open the Wi-Fi panel (\"wifi\")\n\n" +
        "AI understanding, voice, brightness, apps, files and weather come in later stages."

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(12), dp(12), dp(12), dp(8))
        }

        // Header: title + LOG button
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            setTextColor(cyan)
            textSize = 20f
            letterSpacing = 0.3f
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(styledButton("LOG") { showLog() })
        root.addView(header)

        // Orb + status
        orb = OrbView(this)
        root.addView(orb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        status = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 14f
        }
        root.addView(status, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Chat area
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Cancel button (only visible while a task is pending)
        cancelBtn = styledButton("CANCEL TASK") { cancelTask() }
        cancelBtn.visibility = View.GONE
        root.addView(cancelBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Input row
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Type a command..."
            setHintTextColor(0xFF607080.toInt())
            setTextColor(Color.WHITE)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0xFF101826.toInt())
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    submit(text.toString())
                    true
                } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendBtn = styledButton("SEND") { submit(input.text.toString()) }
        row.addView(sendBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = dp(8)
        })
        root.addView(row, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })

        setContentView(root)
        setState(OrbState.IDLE)
        addMessage("Online. Type \"help\" to see what I can do.", false)
    }

    override fun onPause() {
        super.onPause()
        orb.pauseAnim()
    }

    override fun onResume() {
        super.onResume()
        orb.resumeAnim()
    }

    private fun styledButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(cyan)
        isAllCaps = false
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        stateListAnimator = null
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), cyan)
            setColor(0x2200E5FF)
        }
        setOnClickListener { onClick() }
    }

    private fun setState(s: OrbState, label: String? = null) {
        orb.state = s
        status.text = label ?: s.label
        status.setTextColor(s.color)
    }

    private fun addMessage(msg: String, fromUser: Boolean) {
        val tv = TextView(this).apply {
            text = msg
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(if (fromUser) 0x3300E5FF else 0xFF101826.toInt())
            }
        }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            topMargin = dp(6)
            if (fromUser) leftMargin = dp(48) else rightMargin = dp(48)
        }
        chat.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun record(line: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        actionLog.add("$stamp  $line")
    }

    private fun submit(raw: String) {
        val cmd = raw.trim()
        if (cmd.isEmpty() || pending != null) return
        idleTask?.let { handler.removeCallbacks(it) }
        input.setText("")
        addMessage(cmd, true)
        setState(OrbState.THINKING)
        cancelBtn.visibility = View.VISIBLE
        val task = Runnable {
            pending = null
            handleCommand(cmd)
        }
        pending = task
        handler.postDelayed(task, 500)
    }

    private fun cancelTask() {
        val task = pending ?: return
        handler.removeCallbacks(task)
        pending = null
        cancelBtn.visibility = View.GONE
        record("CANCELLED by user")
        addMessage("Cancelled. Nothing was executed.", false)
        setState(OrbState.IDLE)
    }

    private fun handleCommand(cmd: String) {
        setState(OrbState.EXECUTING)
        val lower = cmd.lowercase(Locale.getDefault())
        val result: Pair<Boolean, String> = try {
            when {
                "help" in lower || "what can you do" in lower -> Pair(true, helpText)
                "battery" in lower -> batteryResult()
                "time" in lower || "date" in lower -> Pair(
                    true,
                    SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
                )
                "wifi" in lower || "wi-fi" in lower -> {
                    startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    Pair(true, "Android does not let apps switch Wi-Fi on or off, so I opened the Wi-Fi settings for you.")
                }
                "settings" in lower -> {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                    Pair(true, "Opened system settings.")
                }
                else -> Pair(false, "I don't understand that yet. Type \"help\" to see what I can do.")
            }
        } catch (e: Exception) {
            Pair(false, "Action failed: ${e.message}")
        }

        val ok = result.first
        addMessage(result.second, false)
        record((if (ok) "OK    " else "FAIL  ") + cmd)
        cancelBtn.visibility = View.GONE
        setState(if (ok) OrbState.SUCCESS else OrbState.ERROR)
        val back = Runnable { setState(OrbState.IDLE) }
        idleTask = back
        handler.postDelayed(back, 2000)
    }

    private fun batteryResult(): Pair<Boolean, String> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return Pair(false, "Battery information is unavailable.")
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return Pair(false, "Battery information is unavailable.")
        val pct = level * 100 / scale
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
        return Pair(true, "Battery is at $pct% and " + (if (charging) "charging." else "not charging."))
    }

    private fun showLog() {
        AlertDialog.Builder(this)
            .setTitle("Action log")
            .setMessage(if (actionLog.isEmpty()) "No actions yet." else actionLog.joinToString("\n"))
            .setPositiveButton("Close", null)
            .setNegativeButton("Clear") { _, _ -> actionLog.clear() }
            .show()
    }
}
