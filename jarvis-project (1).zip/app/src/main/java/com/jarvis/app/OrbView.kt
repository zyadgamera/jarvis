package com.jarvis.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

enum class OrbState(val color: Int, val label: String) {
    IDLE(0xFF00E5FF.toInt(), "Standing by"),
    LISTENING(0xFF40C4FF.toInt(), "Listening..."),
    THINKING(0xFFB388FF.toInt(), "Thinking..."),
    EXECUTING(0xFFFFD740.toInt(), "Executing..."),
    SUCCESS(0xFF69F0AE.toInt(), "Done"),
    ERROR(0xFFFF5252.toInt(), "Something went wrong")
}

class OrbView(context: Context) : View(context) {

    var state: OrbState = OrbState.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private var angle = 0f
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val oval = RectF()

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    fun pauseAnim() { if (animator.isRunning) animator.pause() }
    fun resumeAnim() { if (animator.isPaused) animator.resume() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 8f * density
        if (r <= 0f) return
        val c = state.color

        // outer thin ring
        paint.color = c
        paint.alpha = 80
        paint.strokeWidth = 2f * density
        canvas.drawCircle(cx, cy, r, paint)

        // rotating outer arcs
        paint.alpha = 255
        paint.strokeWidth = 4f * density
        oval.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(oval, angle, 90f, false, paint)
        canvas.drawArc(oval, angle + 180f, 60f, false, paint)

        // counter-rotating inner arcs
        val r2 = r * 0.72f
        paint.strokeWidth = 3f * density
        oval.set(cx - r2, cy - r2, cx + r2, cy + r2)
        canvas.drawArc(oval, -angle * 1.5f, 120f, false, paint)
        canvas.drawArc(oval, -angle * 1.5f + 180f, 80f, false, paint)

        // glowing core (pulses when not idle)
        val pulse = if (state == OrbState.IDLE) 1f
        else 1f + 0.10f * sin(Math.toRadians((angle * 6f).toDouble())).toFloat()
        fill.color = c
        fill.alpha = 60
        canvas.drawCircle(cx, cy, r * 0.45f * pulse, fill)
        fill.alpha = 200
        canvas.drawCircle(cx, cy, r * 0.22f * pulse, fill)
    }
}
